Warning: Don't use NVIDIA Profile Inspector unless you know what you're doing.

For advanced NVIDIA settings, use NVIDIA Profile Inspector. 